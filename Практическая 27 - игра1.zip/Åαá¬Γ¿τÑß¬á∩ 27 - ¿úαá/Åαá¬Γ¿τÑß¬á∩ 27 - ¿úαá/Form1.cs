﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.KeyEventHandler;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;

namespace Практическая_27___игра
{
    public partial class Form1 : Form
    {
        void Resize<T>(ref T[,] array, int size2)
        {
            T[,] new_array = new T[array.GetLength(0), size2];
            size2 = Math.Min(array.GetLength(1), size2);
            for (int i = 0; i < array.GetLength(0); i++)
            {
                for (int j = 0; j < size2; j++) new_array[i, j] = array[i, j];
            }
            array = new_array;
        }

        int[] Split(int[,] Massiv, int Sample) 
        {
            if (Sample == 1)
            {
                int[] MassivX = new int[Massiv.GetLength(1)];
                for (int i = 0, j = 0; j < Massiv.GetLength(1); j++) 
                {
                    MassivX[j] = Massiv[i, j];
                }
                return MassivX;
            }
            else 
            {
                int[] MassivY = new int[Massiv.GetLength(1)];
                for (int i = 1, j = 0; j < Massiv.GetLength(1); j++)
                {
                    MassivY[j] = Massiv[i, j];
                }
                return MassivY;
            }
        }

        bool CollisionCoordinates(Rectangle Square, int[] MassivX, int[] MassivY)
        {
            bool Collision = false;
            for (int i = 0; i < MassivX.Length; i++) {
                if (Square.X == MassivX[i] && Square.Y == MassivY[i])
                {
                    Collision = true;
                }
            }
            if (Collision == true) 
            { 
                return true; 
            } 
            else 
            { 
                return false; 
            }
        }

        public Form1()
        {
            InitializeComponent();

            this.KeyPreview = true;//Для того чтобы событие KeyDown работало,
                                   //нужно установить свойство KeyPreview формы в значение true.
                                   //Это позволит форме первой обрабатывать события нажатия клавиш перед тем,
                                   //как они будут переданы элементам управления на форме.

            Cells = new int[2, 0];
        }

        Rectangle Square = new Rectangle(375, 252, 10, 10);
        //  Random rand = new Random();

        int dx = 0;
        int dy = 0;
        int MaxCells = 5;
        int[,] Cells;

        List<Rectangle> CellsList = new List<Rectangle>();

        bool start = false;
        int directionX = 0;
        int directionY = 0;

        private void pBFieldOfPlay_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.FillRectangle(Brushes.DarkGreen, Square);
            foreach (Rectangle cell in CellsList) 
            {
                e.Graphics.FillRectangle(Brushes.Green, cell);
            }
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            Timer timer = new Timer();
            timer.Interval = 100;
            timer.Tick += new EventHandler(CausedLoop);
            timer.Start();
        }

        void CausedLoop(object sender, EventArgs e)
        {
            Loop(Square, dx, dy, ref Cells, CellsList);
        }

        void Loop(Rectangle Square, int dx, int dy, ref int[,] Cells, List<Rectangle> CellsList) { 
            if (btnStartOrStop.Text == "Остановить") {
                if (Cells.GetLength(1) <= MaxCells)
                {

                    Resize(ref Cells, Cells.GetLength(1) + 1);
                    Cells[0, Cells.GetLength(1) - 1] = Square.X;
                    Cells[1, Cells.GetLength(1) - 1] = Square.Y;

                }
                else 
                {
                    CellsList.RemoveAt(0);
                    Cells[0, Cells.GetLength(1) - 1] = Square.X;
                    Cells[1, Cells.GetLength(1) - 1] = Square.Y;
                }

            Square.Offset(dx, dy);
            this.Square = Square;//ВАЖНАЯ ШТУКА

            Rectangle Cell = new Rectangle(Cells[0, Cells.GetLength(1) - 1], Cells[1, Cells.GetLength(1) - 1], 10, 10);
            CellsList.Add(Cell);
            }

            pBFieldOfPlay.Invalidate();

            bool Destroy = CollisionCoordinates(Square, Split(Cells, 1), Split(Cells, 0));
            if (Destroy == true) 
            {
                MessageBox.Show("Мы молодцы");
            }
        }

        private void btnStartOrStop_Click(object sender, EventArgs e)
        {
            if (start == false) {
                if (directionX == 0 && directionY == 0)
                {
                    dx = 0;
                    dy = 10;
                    btnStartOrStop.Text = "Остановить";

                }
                else {
                    dx = directionX;
                    dy = directionY;

                    directionX = 0;
                    directionY = 0;
                    btnStartOrStop.Text = "Остановить";
                }
            }
            if (start == true)
            {
                directionX = dx;
                directionY = dy;

                dx = 0;
                dy = 0;

                start = false;
                btnStartOrStop.Text = "Начать";
            }
            if (directionX == 0 && directionY == 0)
            {
                start = true;
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (btnStartOrStop.Text == "Остановить")
            {
                start = true;

                if ((e.KeyCode == Keys.A || e.KeyCode == Keys.Left) && dx != 10) //Нажатие на стрелки не фиксируется :(
                {
                    dy = 0;
                    dx = -10;
                }
                if ((e.KeyCode == Keys.D || e.KeyCode == Keys.Right) && dx != -10)
                {
                    dy = 0;
                    dx = 10;
                }
                if ((e.KeyCode == Keys.W || e.KeyCode == Keys.Up) && dy != 10)
                {
                    dy = -10;
                    dx = 0;
                }
                if ((e.KeyCode == Keys.S || e.KeyCode == Keys.Down) && dy != -10)
                {
                    dy = 10;
                    dx = 0;
                }
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left && dx != 10)
            {
                dy = 0;
                dx = -10;
            }
            if (e.KeyCode == Keys.Right && dx != -10)
            {
                dy = 0;
                dx = 10;
            }
            if (e.KeyCode == Keys.Up && dy != 10)
            {
                dy = -10;
                dx = 0;
            }
            if (e.KeyCode == Keys.Down && dy != -10)
            {
                dy = 10;
                dx = 0;
            }
        }
    }
}
//  MessageBox.Show(Convert.ToString(Square.X));
//MessageBox.Show("Мы дебилы?");
//Square.Offset(dx,dy);
//ControlPaint.DrawReversibleFrame(Square,SystemColors.Highlight, FrameStyle.Thick);

/* if (e.KeyCode == Keys.Left && dx!=-20)
            {
                dy = 0;
                dx = 20;  
            }
            if (e.KeyCode == Keys.Right && dx != 20)
            {
                dy = 0;
                dx = -20;
            }
            if (e.KeyCode == Keys.Up && dy != -20)
            {
                dy = 20;
                dx = 0;
            }
            if (e.KeyCode == Keys.Down && dy != 20)
            {
                dy = -20;
                dx = 0;
            }*/




/*
    x x x x x
    y y y y y
 
 
 
 
 
 */