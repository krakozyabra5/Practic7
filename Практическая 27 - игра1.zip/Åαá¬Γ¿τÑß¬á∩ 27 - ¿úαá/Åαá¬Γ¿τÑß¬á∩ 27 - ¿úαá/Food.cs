﻿namespace Практическая_27___игра
{
    internal class Food
    {
    }
}