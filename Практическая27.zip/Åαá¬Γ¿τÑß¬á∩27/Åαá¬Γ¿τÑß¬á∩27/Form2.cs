﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Практическая_27___игра
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();

            Form1 Main = this.Owner as Form1;
           
            Form1 form1 = Application.OpenForms.OfType<Form1>().FirstOrDefault();
                lblScore.Text = "Ваш счет: " + form1.Score;

            this.FormBorderStyle = FormBorderStyle.FixedDialog; // мышкой нельзя растягивать форму
            this.StartPosition = FormStartPosition.CenterScreen; // форма отображается по центру экрана
            this.MaximizeBox = false; // делаем недоступной кнопку "развернуть во весь экран"
            this.ControlBox = false;// сделать кнопку "закрыть программу" недоступной через свойство ControlBox
        }

        private void btnEndGame_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        private void btnPlayAgain_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
