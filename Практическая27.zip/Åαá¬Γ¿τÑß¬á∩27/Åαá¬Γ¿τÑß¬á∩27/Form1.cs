﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Media;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.KeyEventHandler;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;


namespace Практическая_27___игра
{
    public partial class Form1 : Form
    {
        private void playSimpleSound()
        {
            SoundPlayer simpleSound = new SoundPlayer(@"C:\Users\I'm\Desktop\Практическая27\music\Hrym.wav");
            simpleSound.Play();
        }

        void Resize<T>(ref T[,] array, int size2)
        { 
            T[,] new_array = new T[array.GetLength(0), size2];
            size2 = Math.Min(array.GetLength(1), size2);
            for (int i = 0; i < array.GetLength(0); i++)
            {
                for (int j = 0; j < size2; j++)
                { 
                    new_array[i, j] = array[i, j]; 
                }
            }
            array = new_array;
        }

        //Рвзбитие двумерного массива на массив значений X или массив значений Y
        int[] Split(ref int[,] Massiv, int Sample) 
        {
            if (Sample == 1)
            {
                int[] MassivX = new int[Massiv.GetLength(1)];
             
                for (int i = 0, j = 0; j < Massiv.GetLength(1); j++) 
                {
                    MassivX[j] = Massiv[i, j];
                }
                return MassivX;
            }
            else 
            {
                int[] MassivY = new int[Massiv.GetLength(1)];
                for (int i = 1, j = 0; j < Massiv.GetLength(1); j++)
                {
                    MassivY[j] = Massiv[i, j];
                }
                return MassivY;
            }
        }

        //Сравнение координаты головы-змеи с какими-то координатами
        bool CollisionCoordinates(Rectangle Square, int[] MassivX, int[] MassivY)
        {
            bool Collision = false;
            for (int i = 0; i < MassivX.Length; i++) 
            {
                if (this.Square.X == MassivX[i] && this.Square.Y == MassivY[i] || this.Square.X <= 0 || this.Square.Y <= 0
                                                                               || this.Square.X >= pBFieldOfPlay.Width || this.Square.Y >= pBFieldOfPlay.Height)
                {
                    Collision = true;
                }
            }
            if (Collision == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //Сдвиг элементов массива по столбцу
        int[,] DislocationColumn(int[,] Massiv, int Number)
        {
            for (int j = Number; j < Massiv.GetLength(1)-1; j++)
            {
                Massiv[0, j] = Massiv[0, j + 1];
                Massiv[1, j] = Massiv[1, j + 1];
            }
            return Massiv;
        }


        public Form1()
        {
            InitializeComponent();

           

            this.KeyPreview = true;//Для того чтобы событие KeyDown работало,
                                   //нужно установить свойство KeyPreview формы в значение true.
                                   //Это позволит форме первой обрабатывать события нажатия клавиш перед тем,
                                   //как они будут переданы элементам управления на форме.

            this.FormBorderStyle = FormBorderStyle.FixedDialog; // мышкой нельзя растягивать форму
            this.MaximizeBox = false; // делаем недоступной кнопку "развернуть во весь экран"
            this.StartPosition = FormStartPosition.CenterScreen; // форма отображается по центру экрана
           
            //массив значений X и Y
            Cells = new int[2, 0];

        }

        Rectangle Square = new Rectangle(370, 250, 10, 10);
        Rectangle Apple;


        int AppleX = 1;
        int AppleY = 1;

        int dx = 0;
        int dy = 0;

        //макс. длина змеи в начале игры
        int MaxCells = 5;
        //Массив содержащий координаты каждой клетки хвоста-змеи
        int[,] Cells;

        //Список содержащий координаты каждой клетки хвоста-змеи
        List<Rectangle> CellsList = new List<Rectangle>();

        bool start = false;
        bool form2open = false;

        public int Score = 0;
        int MaxScore = 0;

        //Направление змеи 
        int directionX = 0;
        int directionY = 0;

        //Отрисовка змеи (головы и хвоста)
        private void pBFieldOfPlay_Paint(object sender, PaintEventArgs e)
        {
            foreach (Rectangle cell in CellsList) 
            {
                e.Graphics.FillRectangle(Brushes.Green, cell);
            }
            e.Graphics.FillRectangle(Brushes.DarkRed, Apple); 
            e.Graphics.FillRectangle(Brushes.DarkGreen, Square);
        }

        //Таймер вызывающий событие движения
        private void Form1_Shown(object sender, EventArgs e)
        {
            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            timer.Interval = 100;
            timer.Tick += new EventHandler(CausedLoop);
            timer.Start();
        }

        //Доп.событие для события движения 
        void CausedLoop(object sender, EventArgs e)
        {
            Loop(Square, dx, dy, ref Cells, CellsList);
        }

        //Событие движения
        void Loop(Rectangle Square, int dx, int dy, ref int[,] Cells, List<Rectangle> CellsList)
        {
            if (btnStartOrStop.Text == "Остановить") 
            {   //Когда змея маленькая
                if (Cells.GetLength(1) <= MaxCells)
                {
                    Resize(ref Cells, Cells.GetLength(1) + 1);
                    Cells[0, Cells.GetLength(1) - 1] = Square.X;
                    Cells[1, Cells.GetLength(1) - 1] = Square.Y;

                }
                //когда змея полная
                else 
                {
                    if (CellsList.Count != 0) 
                    {
                        CellsList.RemoveAt(0);
                    }
                    Cells = DislocationColumn(Cells, 0);
                    Cells[0, Cells.GetLength(1) - 1] = Square.X;
                    Cells[1, Cells.GetLength(1) - 1] = Square.Y;
                }
            //Изменение координат головы (движение)
            Square.Offset(dx, dy);
            this.Square = Square;//ВАЖНАЯ ШТУКА

            //Создание клетки хвоста
            Rectangle Cell = new Rectangle(Cells[0, Cells.GetLength(1) - 1], Cells[1, Cells.GetLength(1) - 1], 10, 10);
            CellsList.Add(Cell);
            }
            //Обновление холста
            pBFieldOfPlay.Invalidate();

            //Проверка на столкновение головы змеи с хвостом
            bool endistail = CollisionCoordinates(Square, Split(ref Cells, 1), Split(ref Cells, 0));
            if (endistail == true)
            {
                start = false;
                btnStartOrStop.Text = "Начать";
                dx = 0;
                dy = 10;
     
                Form2 form2 = Application.OpenForms.OfType<Form2>().FirstOrDefault();
                if (form2 == null && form2open == false) {
                    form2open = true;
                    Form2 AddRec = new Form2();
                    AddRec.Owner = this;
                    AddRec.ShowDialog();

                    CellsList.Clear();
                    Cells = new int[2, 0];
                    MaxCells = 5;
                    this.Square.X = 370;
                    this.Square.Y = 250;
                    AppleX = -11;
                    AppleY = -11;
                    Apple = new Rectangle(AppleX, AppleY, 10, 10);
                    pBFieldOfPlay.Invalidate();


                    if (MaxScore < Score) 
                    {
                        MaxScore = Score;
                        lblMaxScore.Text = "Масксимальное количество очков: " + MaxScore;
                        lblScore.Text = $"Очки: 0";
                    }
                    Score = 0;
                }
            }
            form2open = false;

            Random rand = new Random();
            if (btnStartOrStop.Text == "Остановить") 
            {
                while (AppleX % 10 != 0) {
                    AppleX = rand.Next(10, pBFieldOfPlay.Width - 9);
                }
                while (AppleY % 10 != 0)
                {
                    AppleY = rand.Next(10, pBFieldOfPlay.Height - 9);
                }
                Apple = new Rectangle(AppleX, AppleY, 10, 10);
            }
         
            if (Square.X == AppleX && Square.Y == AppleY) 
            {
                Score += 1;
                MaxCells += 1;
                lblScore.Text = "Очки: " + Score;

                AppleX = -11;
                AppleY = -11;

                playSimpleSound();
            }
    
        }

        //Кнопка начать/остановить
        private void btnStartOrStop_Click(object sender, EventArgs e)
        {
            if (start == false) {
                if (directionX == 0 && directionY == 0)
                {
                    dx = 0;
                    dy = 10;
                    btnStartOrStop.Text = "Остановить";

                }
                else {
                    dx = directionX;
                    dy = directionY;

                    directionX = 0;
                    directionY = 0;
                    btnStartOrStop.Text = "Остановить";
                }
            }
            if (start == true)
            {
                directionX = dx;
                directionY = dy;

                dx = 0;
                dy = 0;

                start = false;
                btnStartOrStop.Text = "Начать";
            }
            if (directionX == 0 && directionY == 0)
            {
                start = true;
            }
        }

        //Клавиши
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (btnStartOrStop.Text == "Остановить")
            {
                start = true;

                if ((e.KeyCode == Keys.A || e.KeyCode == Keys.Left) && dx != 10) //Нажатие на стрелки не фиксируется :(
                {
                    dy = 0;
                    dx = -10;
                }
                if ((e.KeyCode == Keys.D || e.KeyCode == Keys.Right) && dx != -10)
                {
                    dy = 0;
                    dx = 10;
                }
                if ((e.KeyCode == Keys.W || e.KeyCode == Keys.Up) && dy != 10)
                {
                    dy = -10;
                    dx = 0;
                }
                if ((e.KeyCode == Keys.S || e.KeyCode == Keys.Down) && dy != -10)
                {
                    dy = 10;
                    dx = 0;
                }
            }
        }
       
        //Клавиши
        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left && dx != 10)
            {
                dy = 0;
                dx = -10;
            }
            if (e.KeyCode == Keys.Right && dx != -10)
            {
                dy = 0;
                dx = 10;
            }
            if (e.KeyCode == Keys.Up && dy != 10)
            {
                dy = -10;
                dx = 0;
            }
            if (e.KeyCode == Keys.Down && dy != -10)
            {
                dy = 10;
                dx = 0;
            }
        }

    }
}

//MessageBox.Show("Мы дебилы?");

//ControlPaint.DrawReversibleFrame(Square,SystemColors.Highlight, FrameStyle.Thick);   - моргающий квадарт (внутри и снаружи формы)


/* Cells
    x x x x x
    y y y y y
 */


